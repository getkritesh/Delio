var KToken = artifacts.require("KToken");

module.exports = function(deployer) {
    deployer.deploy(KToken);
};